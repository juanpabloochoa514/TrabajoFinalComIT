package repositories;

public class CommonRepository {

	public static AlimentosRepository AliemntoRepoName = new AlimentosRepository(); //atributo de clase
	public static AlimentosCongRepository ALimentosCongeladosRepoName = new AlimentosCongRepository();
}
